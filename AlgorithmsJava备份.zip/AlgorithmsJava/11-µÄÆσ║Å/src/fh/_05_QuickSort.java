package fh;

public class _05_QuickSort {
    static void quickSort(int[] array) {

    }


    public static void main(String[] args) {
        int[] array = {9,8,7,6,3,4,2,1};
        quickSort(array);
        for (int i = 0; i < array.length; i++) {
            System.out.print(array[i]+ "_");
        }
    }
}
