package fh;

public class _04_LCS {

}
