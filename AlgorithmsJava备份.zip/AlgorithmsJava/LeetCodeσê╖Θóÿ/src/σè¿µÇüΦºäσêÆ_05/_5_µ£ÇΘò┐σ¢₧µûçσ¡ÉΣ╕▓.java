package 动态规划_05;

/*
* https://leetcode-cn.com/problems/longest-palindromic-substring/
* */
public class _5_最长回文子串 {
    /*
    * 解法1: 动态规划
    * */
    public String longestPalindrome(String s) {
        return "";
    }

    /*
     * 解法2: 扩展中心法
     * */
    public String longestPalindrome1(String s) {
       return "abc";
    }

    /*
     * 解法3: 基于扩展中心的优化
     * */
    public String longestPalindrome2(String s) {
        return "abc";
    }
    /*
     * 解法4: 马拉车算法
     * */
    public String longestPalindrome3(String s) {
        return "abc";
    }
}
