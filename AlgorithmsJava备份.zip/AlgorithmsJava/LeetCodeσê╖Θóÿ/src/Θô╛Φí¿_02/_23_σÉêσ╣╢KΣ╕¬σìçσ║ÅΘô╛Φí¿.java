package 链表_02;

/*
* https://ke.qq.com/webcourse/436549/100521301#taid=3581891056150853&vid=5285890794196082042
* */
public class _23_合并K个升序链表 extends _00_baseList {
    public ListNode mergeKLists(ListNode[] lists) {
        return new ListNode(0);
    }
}
